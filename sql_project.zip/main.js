// Toggle Sidebar
function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const main = document.getElementById('main');
  
  sidebar.classList.toggle('collapsed');
  main.classList.toggle('expanded');
}

// Close sidebar when clicking outside
document.addEventListener('DOMContentLoaded', function() {
  document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.querySelector('.menu-btn');
    
    if (sidebar.classList.contains('active') &&
      !sidebar.contains(event.target) &&
      !menuBtn.contains(event.target)) {
      sidebar.classList.remove('active');
    }
  });
  
  // Set active navigation item
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.sidebar a');
  
  navLinks.forEach(link => {
    if (link.getAttribute('href') === currentPath.split('/').pop()) {
      link.classList.add('active');
    }
  });
});

// Simple SQL editor functionality
function runSQL() {
  const sqlCode = document.getElementById('sqlCode').value;
  const resultDiv = document.getElementById('result');
  
  // This is a mock function - in a real application, 
  // you would send the SQL code to a server for execution
  resultDiv.innerHTML = '<p>Query executed successfully. Results would appear here in a real application.</p>';
  
  // Show a simple example result based on the query
  if (sqlCode.toUpperCase().includes('SELECT')) {
    resultDiv.innerHTML = `
            <table class="result-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>john@example.com</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Jane Smith</td>
                        <td>jane@example.com</td>
                    </tr>
                </tbody>
            </table>
        `;
  }
}

// Copy code functionality
function copyCode(codeId) {
  const codeElement = document.getElementById(codeId);
  const textArea = document.createElement('textarea');
  textArea.value = codeElement.textContent;
  document.body.appendChild(textArea);
  textArea.select();
  document.execCommand('copy');
  document.body.removeChild(textArea);
  
  // Show notification
  const notification = document.createElement('div');
  notification.textContent = 'Kode berhasil disalin!';
  notification.style.position = 'fixed';
  notification.style.bottom = '20px';
  notification.style.right = '20px';
  notification.style.backgroundColor = '#4e73df';
  notification.style.color = 'white';
  notification.style.padding = '10px 20px';
  notification.style.borderRadius = '4px';
  notification.style.zIndex = '1000';
  document.body.appendChild(notification);
  
  setTimeout(() => {
    document.body.removeChild(notification);
  }, 3000);
}

// Highlight SQL syntax
function highlightSQL(code) {
  return code
    .replace(/\b(SELECT|FROM|WHERE|INSERT|INTO|UPDATE|DELETE|CREATE|TABLE|DROP|ALTER|PRIMARY|KEY|FOREIGN|REFERENCES|NOT|NULL|DEFAULT|AUTO_INCREMENT|UNIQUE|CHECK|AND|OR|NOT|IN|BETWEEN|LIKE|IS|NULL|ORDER|BY|GROUP|HAVING|JOIN|INNER|LEFT|RIGHT|FULL|OUTER|ON|AS|DISTINCT|COUNT|SUM|AVG|MIN|MAX|CASE|WHEN|THEN|ELSE|END|UNION|ALL|EXISTS|ANY|SOME)\b/gi, '<span class="keyword">$1</span>')
    .replace(/'([^']*)'/g, '<span class="string">\'$1\'</span>')
    .replace(/"([^"]*)"/g, '<span class="string">"$1"</span>')
    .replace(/(\d+)/g, '<span class="number">$1</span>')
    .replace(/(--[^\n]*)/g, '<span class="comment">$1</span>');
}

// Apply syntax highlighting to code examples
document.addEventListener('DOMContentLoaded', function() {
  const codeExamples = document.querySelectorAll('.code-example pre');
  
  codeExamples.forEach(example => {
    if (!example.classList.contains('highlighted')) {
      example.innerHTML = highlightSQL(example.innerHTML);
      example.classList.add('highlighted');
    }
  });
});

// Smooth scrolling for anchor links
document.addEventListener('DOMContentLoaded', function() {
  const anchorLinks = document.querySelectorAll('a[href^="#"]');
  
  anchorLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: 'smooth'
        });
      }
    });
  });
});

// Progress indicator for tutorial
function updateProgress() {
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.sidebar a');
  let currentIndex = 0;
  
  navLinks.forEach((link, index) => {
    if (link.getAttribute('href') === currentPath.split('/').pop()) {
      currentIndex = index;
    }
  });
  
  const progress = (currentIndex / (navLinks.length - 1)) * 100;
  
  // Create or update progress bar
  let progressBar = document.getElementById('progress-bar');
  
  if (!progressBar) {
    progressBar = document.createElement('div');
    progressBar.id = 'progress-bar';
    progressBar.style.position = 'fixed';
    progressBar.style.top = '0';
    progressBar.style.left = '0';
    progressBar.style.height = '4px';
    progressBar.style.backgroundColor = '#4e73df';
    progressBar.style.zIndex = '1001';
    progressBar.style.transition = 'width 0.3s';
    document.body.appendChild(progressBar);
  }
  
  progressBar.style.width = `${progress}%`;
}

// Update progress on page load
document.addEventListener('DOMContentLoaded', updateProgress);